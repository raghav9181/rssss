# GCC Intelligence — Clickable UI Prototype

This is a self-contained, responsive HTML prototype. It needs no build tools or dependencies.

## Run
Open `index.html` in a modern browser, or serve the folder:
```bash
python -m http.server 8080
```
Then visit http://localhost:8080.

## Included interactions
- Change headcount, function, growth, budget, and tax scenario
- Recalculate city operating-cost comparisons and illustrative tax projections
- Sort locations by fit score or lowest cost
- Export the current comparison to CSV
- Navigate sample state-incentive and vendor-network views
- Create a local demo RFP prompt and maintain a local vendor-category shortlist

## Data caveat
All location figures and non-WOS tax rates are synthetic demo assumptions. The UI does not connect to a backend or live data source. Validate tax rules with Indian tax counsel and replace market assumptions with source-attributed, dated data before using for decisions.
